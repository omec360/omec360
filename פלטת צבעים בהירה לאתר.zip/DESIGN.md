# Design System Document: High-End Editorial

## 1. Overview & Creative North Star: "The Digital Atelier"

This design system is built to evoke the tactile, intentional atmosphere of a boutique high-end studio. Our Creative North Star is **The Digital Atelier**. We are moving away from the "templated" web—characterized by rigid borders and aggressive grids—and moving toward a space that feels curated, breathable, and organic.

To achieve this, we lean into **intentional asymmetry** and **tonal depth**. The UI should feel like a series of fine paper stocks layered atop one another. We reject the "standard" digital interface in favor of editorial layouts, where generous white space is not "empty" but is a functional element of luxury.

---

## 2. Colors & Surface Philosophy

The palette is anchored in warmth. It avoids the sterile coldness of pure white (#FFFFFF) and the harshness of pure black (#000000), opting instead for cream foundations and charcoal ink.

### The "No-Line" Rule
**Explicit Instruction:** Designers are prohibited from using 1px solid borders to section content. Traditional "boxes" make an interface look cheap. Boundaries must be defined solely through background color shifts or subtle tonal transitions. Use `surface-container-low` against a `surface` background to create a section; do not draw a line between them.

### Surface Hierarchy & Nesting
Treat the UI as physical layers of premium cardstock.
*   **Base Layer:** `surface` (#fbf9f5) or `background` (#fbf9f5).
*   **The Inset:** Use `surface-container-low` (#f5f3ef) for large structural areas (like a sidebar or a secondary content block).
*   **The Lift:** Use `surface-container-lowest` (#ffffff) for card elements to create a "bright" pop against the cream background.
*   **The Depth:** Use `surface-container-high` (#eae8e4) for interactive elements like hover states or recessed wells.

### The "Glass & Gradient" Rule
To add "soul" to the digital experience:
*   **Glassmorphism:** For floating navigation or modals, use `surface` at 80% opacity with a `backdrop-filter: blur(20px)`. This allows the "sand" tones to bleed through the UI.
*   **Signature Gradients:** For primary CTAs and Hero backgrounds, use a subtle linear gradient from `primary` (#775a19) to `primary-container` (#dab36a). This mimics the way light hits a gilded surface.

---

## 3. Typography: Editorial Authority

We use **Plus Jakarta Sans** exclusively. Its modern geometry, when paired with specific styling, creates a bespoke editorial feel.

*   **Display (lg/md/sm):** These are your "statements." Use `display-lg` (3.5rem) with a tight line-height (1.1) but wide letter-spacing (-0.02em) to create a high-fashion masthead look.
*   **Headline & Title:** These guide the user. Always use `on-surface` (#1b1c1a). Ensure `headline-lg` has generous top-padding to let the type breathe.
*   **Body (lg/md/sm):** Body text should feel like a well-set novel. Use `body-lg` (1rem) for long-form content to maintain a premium, readable feel.
*   **Labels:** Use `label-md` with **0.1em letter spacing** and all-caps for a "studio tag" aesthetic. This identifies the brand’s professional rigor.

---

## 4. Elevation & Depth: Tonal Layering

Shadows and lines are the enemies of this system. We convey hierarchy through light and material density.

*   **The Layering Principle:** Instead of a shadow, place a `surface-container-lowest` card on a `surface-container-low` section. The 2% difference in luminosity creates a soft, natural lift.
*   **Ambient Shadows:** If an element must float (e.g., a dropdown), use an extra-diffused shadow: `box-shadow: 0 20px 40px rgba(27, 28, 26, 0.05)`. Note the 5% opacity; it should be felt, not seen.
*   **The "Ghost Border" Fallback:** If accessibility requires a container boundary, use the `outline-variant` (#d1c5b7) at **15% opacity**. This creates a "whisper" of a line that defines space without cluttering the visual field.

---

## 5. Components

### Buttons
*   **Primary:** A gradient fill (Primary to Primary-Container) with `on-primary` (#ffffff) text. Use `rounded-sm` (0.125rem) for a sharp, architectural feel.
*   **Secondary:** `surface-container-highest` background with `on-surface` text. No border.
*   **Tertiary:** Text-only with a subtle `label-md` underline that appears on hover.

### Cards & Lists
*   **Constraint:** Forbid the use of divider lines between list items. Use 24px of vertical white space (Spacing Scale) to separate items.
*   **Structure:** Cards should use the `surface-container-lowest` fill. Use an asymmetrical layout within the card—place the image off-center to break the "grid" feel.

### Input Fields
*   **Styling:** Inputs should not be boxes. Use a "Soft Well" approach: a `surface-container-low` background with a `rounded-none` bottom border in `outline-variant` (20% opacity). 
*   **Focus State:** Transition the background to `surface-container-highest` and the bottom border to `primary`.

### Navigation (The Studio Header)
*   Use a wide horizontal layout with `label-md` typography. 
*   Incorporate a "Glassmorphism" blur to ensure the header feels integrated into the scroll, not "stuck" to the top.

---

## 6. Do’s and Don’ts

### Do:
*   **Do** use asymmetrical margins. If a text block is 6 columns wide, offset it by 1 column to the right to create visual interest.
*   **Do** use "Surface Tints" for interactive states. A 5% `surface-tint` overlay on a card is better than a dark shadow.
*   **Do** emphasize high-quality imagery. This system relies on photography that shares the warm, desaturated tones of the palette.

### Don't:
*   **Don't** use 100% black text. Always use `on-surface` (#1b1c1a) for a softer, more luxurious ink-on-paper look.
*   **Don't** use standard "pill" buttons unless they are Chips. High-end design favors the architectural stability of `rounded-sm` or `rounded-md`.
*   **Don't** crowd the edges. If you think there is enough padding, add 16px more. Luxury is space.