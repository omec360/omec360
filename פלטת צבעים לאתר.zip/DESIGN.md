# Design System Document: High-End Editorial

## 1. Overview & Creative North Star
The **Creative North Star** for this design system is **"The Nocturnal Gallery."** 

Moving away from the standard corporate "SaaS" look, this system embraces a sophisticated, deep-sea palette and editorial layouts that feel curated rather than assembled. We break the rigid, modular grid by employing intentional asymmetry, overlapping high-end imagery, and generous breathing room. This is not just a website; it is a premium digital experience where depth is achieved through light and shadow rather than lines and boxes.

By utilizing "The Nocturnal Gallery" philosophy, we ensure that every interaction feels intentional. We treat the screen as a canvas where the hierarchy is driven by massive typography scales and subtle tonal shifts, creating a sanctuary for content.

---

## 2. Colors: Tonal Depth
Our palette is anchored in deep teals and oceanic blues, punctuated by a surgical use of high-contrast yellow (`secondary`).

### The "No-Line" Rule
**Borders are strictly prohibited for sectioning.** To separate content, designers must use background color shifts. For example, a hero section in `surface` (`#001620`) might transition into a feature section using `surface-container-low` (`#001e2b`). 

### Surface Hierarchy & Nesting
Treat the UI as layered sheets of frosted glass. 
- **Lowest Depth:** `surface_container_lowest` (#001019) for the most recessed elements or backdrop gaps.
- **Base Layer:** `surface` (#001620) for the primary canvas.
- **Elevated Surfaces:** Use `surface_bright` (#1c3d4c) to pull a component toward the user.

### The "Glass & Gradient" Rule
To add "soul," primary CTAs and hero backgrounds should utilize subtle gradients. Transitioning from `primary` (#b3c9de) to `primary_container` (#1a3040) creates a metallic, premium sheen. For floating navigation or modals, apply **Glassmorphism**: use `surface_variant` (#173848) at 60% opacity with a `24px` backdrop-blur.

---

## 3. Typography: Editorial Authority
The typography system relies on the interplay between the architectural **Plus Jakarta Sans** and the functional **Inter**, with **Space Grotesk** providing a technical, modern edge for labels.

*   **Display (Plus Jakarta Sans):** Used for "Hero" moments. The massive `3.5rem` scale creates an immediate editorial feel. 
*   **Headline (Plus Jakarta Sans):** These are the anchors of your layout. Use `headline-lg` to introduce major shifts in the narrative.
*   **Body (Inter):** High legibility. The transition from `headline` (serif-like personality) to `body` (geometric sans) creates a professional, contemporary tension.
*   **Labels (Space Grotesk):** All-caps with increased letter spacing for meta-data, categories, or small accents. This adds a "studio" or "gallery" aesthetic to technical details.

---

## 4. Elevation & Depth: Tonal Layering
Traditional drop shadows and borders are replaced by **Tonal Layering** and **Ambient Light.**

### The Layering Principle
Hierarchy is achieved by "stacking." A card does not need a shadow if it is a `surface-container-high` (#092e3d) element sitting on a `surface-container-low` (#001e2b) background. This creates a soft, natural "lift."

### Ambient Shadows
If a floating element (like a FAB or floating Nav) requires a shadow, it must be "Ambient":
- **Blur:** 40px–60px.
- **Opacity:** 4%–8%.
- **Color:** Use a tinted version of `on-surface` (a very dark blue-teal) rather than pure black to keep the shadows feeling integrated into the atmosphere.

### The "Ghost Border" Fallback
If accessibility requires a container boundary, use a **Ghost Border**: `outline-variant` (#43474c) at **15% opacity**. It should be felt, not seen.

---

## 5. Components: Studio-Grade Primitives

### Buttons
*   **Primary:** A gradient from `secondary_fixed` (#f6e611) to `secondary_container` (#f0e000). Use `secondary_fixed_dim` for the hover state. No borders. `0.25rem` (sm) roundedness to maintain a sharp, professional edge.
*   **Tertiary:** Text-only in `primary`. Use an animated underline that expands from the center on hover.

### Cards & Lists
*   **The Divider Ban:** Never use horizontal rules. Separate list items using `1.5rem` of vertical white space or by alternating background tones (`surface-container-low` vs. `surface-container-lowest`).
*   **Image Cards:** Images should have a `0.5rem` (lg) corner radius. Use a `surface_variant` overlay at 20% to ensure `on_surface` text remains accessible over photography.

### Input Fields
*   **Style:** Minimalist. No four-sided boxes. Use a `surface_container_highest` background with a bottom-only `Ghost Border`. 
*   **Interaction:** On focus, the bottom border transitions to `secondary` (yellow) with a 2px height.

### Signature Component: The "Content Spotlight"
A custom layout pattern where a `display-md` headline overlaps a high-quality image by 20%—the headline sits on a `Glassmorphism` plate to ensure readability while creating a deep, 3D editorial layer.

---

## 6. Do's and Don'ts

### Do
*   **Do** use asymmetrical layouts. Place text on the left and imagery slightly offset on the right to create visual interest.
*   **Do** use the full `3.5rem` Display scale for impact.
*   **Do** rely on `surface` color shifts to define content blocks.
*   **Do** ensure the yellow `secondary` is used sparingly—only for primary actions and critical highlights.

### Don't
*   **Don't** use 1px solid, 100% opaque borders. They flatten the experience and look "templated."
*   **Don't** use pure black or pure grey for shadows. Use tinted teals to maintain the "Nocturnal Gallery" vibe.
*   **Don't** crowd the layout. If in doubt, add more white space (or "Dark Space" in this context).
*   **Don't** use `Assistant` at 100% weight for everything; lean into the specific tokenized weights of `Plus Jakarta Sans` for hierarchy.